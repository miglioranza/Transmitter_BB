% (c) Copyright 2016 Xilinx, Inc. All rights reserved.
%
% This file contains confidential and proprietary information
% of Xilinx, Inc. and is protected under U.S. and
% international copyright and other intellectual property
% laws.
%
% DISCLAIMER
% This disclaimer is not a license and does not grant any
% rights to the materials distributed herewith. Except as
% otherwise provided in a valid license issued to you by
% Xilinx, and to the maximum extent permitted by applicable
% law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
% WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
% AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
% BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
% INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
% (2) Xilinx shall not be liable (whether in contract or tort,
% including negligence, or under any other theory of
% liability) for any loss or damage of any kind or nature
% related to, arising under or in connection with these
% materials, including for any direct, or any indirect,
% special, incidental, or consequential loss or damage
% (including loss of data, profits, goodwill, or any type of
% loss or damage suffered as a result of any action brought
% by a third party) even if such damage or loss was
% reasonably foreseeable or Xilinx had been advised of the
% possibility of the same.
%
% CRITICAL APPLICATIONS
% Xilinx products are not designed or intended to be fail-
% safe, or for use in any application requiring fail-safe
% performance, such as life-support or safety devices or
% systems, Class III medical devices, nuclear facilities,
% applications related to the deployment of airbags, or any
% other applications that could lead to death, personal
% injury, or severe property or environmental damage
% (individually and collectively, "Critical
% Applications"). Customer assumes the sole risk and
% liability of any use of Xilinx products in Critical
% Applications, subject only to applicable laws and
% regulations governing limitations on product liability.
%
% THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
% PART OF THIS FILE AT ALL TIMES.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;

fprintf('Running LDPC example....\n');

% Create instance
cnfg.name='LDPC';
cnfg.fec = 1; % 0 = Turbo 1 = LDPC
ldpc = sd_fec_v1_1_bitacc(cnfg);

% Generate LDPC parameters and add to model
fprintf('Generate LDPC parameters....\n');
load test.mat;                        % Load parity check matrix (H)
h_size = size(h);
k = h_size(2) - h_size(1);
gen_ldpc_spec(h,psize,'spec.yml');    % Generate specification file, unnecessary if specification file available
% add_ldpc_params(ldpc,0,'test.yml');      % Add LDPC code to model
add_ldpc_params(ldpc,0,'spec.yml');      % Add LDPC code to model

% Confirm matrix to specification conversion
h_ref = gen_parity_check_mat('spec.yml'); % Load parity check matrix from reference specification
if sum(sum(h-h_ref)) > 0
  error('Error in read back matrix');
end

% Encode
fprintf('Encode....\n');

% Define control packet
ctrl.code           = 0;   % Select LDPC code, identifier defined by add_ldpc_params
ctrl.op             = 1;   % Operation: 0=Decoder 1=Encode

bits=double(rand(1,k)>0.5);

% Run encode
[encbits,stats]=process(ldpc,ctrl,bits);

% Convert to LLRs and corrupt some bits
llrbits = 16 * ((2*double(encbits))-1);

llrbits(10) = -llrbits(10);
llrbits(1024) = -llrbits(1024);

err_bits = sum(abs(bits - (llrbits(1:k).'>=0)));
fprintf('Errors introduced: %d\n',err_bits);

% Decode
fprintf('Decode....\n');

ctrl.code              = 0;   % Select LDPC code, identifier defined by add_ldpc_params
ctrl.op                = 0;   % Operation: 0=Decoder 1=Encode
ctrl.hard_op           = 1;   % Hard o/p
ctrl.max_iterations    = 8;   % Max iterations (decode only)
ctrl.id                = 0;   % User ID
ctrl.term_on_pass      = 1;   % Terminate on parity pass
ctrl.term_on_no_change = 0;   % Terminate if hard decision of codeword does not change between iterations

% Run decode
[decbits,stats]=process(ldpc,ctrl,llrbits);
fprintf('Decoder iterations: %d\n',stats.dec_iter);

% Determine number of bits in error
err_bits = sum(abs(bits - double(decbits(1:k).')));
fprintf('Errors after decode: %d\n',err_bits);

fprintf('Running Turbo example....\n');

% Create instance
cnfg.name='Turbo';
cnfg.fec = 0; % 0 = Turbo 1 = LDPC
turbo = sd_fec_v1_1_bitacc(cnfg);

% Turbo parameters
td_params.alg   = 0;   % MAX/MAXSCALE = 0 MAXSTAR = 1
td_params.scale = 12;  % MAXSCALE factor = scale/16

set_turbo_params(turbo,td_params);

% Control
ctrl.code              = 2048;  % Select Turbo block size
ctrl.op                = 0;     % N/A
ctrl.hard_op           = 1;     % Hard o/p
ctrl.max_iterations    = 8;     % Max iterations
ctrl.id                = 0;     % User ID
ctrl.term_on_pass      = 0;     % Terminate on crc pass
ctrl.term_on_no_change = 0;     % Terminate if hard decision of codeword does not change between iterations
ctrl.crc_type          = 0;     % Turbo CRC check: 0=Code block 1=Transport block 

% Using zero data for example
llrbits = -4 * ones(3*ctrl.code+12,1);

% Corrupt some bits
llrbits(10) = -llrbits(10);
llrbits(1024) = -llrbits(1024);

err_bits = sum((llrbits(1:k).'>=0));
fprintf('Errors introduced: %d\n',err_bits);

% Run decode
[decbits,stats]=process(turbo,ctrl,llrbits);
fprintf('Decoder iterations: %d\n',stats.dec_iter);

% Determine number of bits in error
err_bits = sum(double(decbits));
fprintf('Errors after decode: %d\n',err_bits);

%-----------------------------------------------------------------------------
%  (c) Copyright 2016 Xilinx, Inc. All rights reserved.
%
%  This file contains confidential and proprietary information
%  of Xilinx, Inc. and is protected under U.S. and
%  international copyright and other intellectual property
%  laws.
%
%  DISCLAIMER
%  This disclaimer is not a license and does not grant any
%  rights to the materials distributed herewith. Except as
%  otherwise provided in a valid license issued to you by
%  Xilinx, and to the maximum extent permitted by applicable
%  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
%  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
%  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
%  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
%  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
%  (2) Xilinx shall not be liable (whether in contract or tort,
%  including negligence, or under any other theory of
%  liability) for any loss or damage of any kind or nature
%  related to, arising under or in connection with these
%  materials, including for any direct, or any indirect,
%  special, incidental, or consequential loss or damage
%  (including loss of data, profits, goodwill, or any type of
%  loss or damage suffered as a result of any action brought
%  by a third party) even if such damage or loss was
%  reasonably foreseeable or Xilinx had been advised of the
%  possibility of the same.
%
%  CRITICAL APPLICATIONS
%  Xilinx products are not designed or intended to be fail-
%  safe, or for use in any application requiring fail-safe
%  performance, such as life-support or safety devices or
%  systems, Class III medical devices, nuclear facilities,
%  applications related to the deployment of airbags, or any
%  other applications that could lead to death, personal
%  injury, or severe property or environmental damage
%  (individually and collectively, "Critical
%  Applications"). Customer assumes the sole risk and
%  liability of any use of Xilinx products in Critical
%  Applications, subject only to applicable laws and
%  regulations governing limitations on product liability.
%
%  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
%  PART OF THIS FILE AT ALL TIMES.
%-----------------------------------------------------------------------------
