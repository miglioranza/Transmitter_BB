//-----------------------------------------------------------------------------
// (c) Copyright 2016 Xilinx, Inc. All rights reserved.
//
// This file contains confidential and proprietary information
// of Xilinx, Inc. and is protected under U.S. and
// international copyright and other intellectual property
// laws.
//
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// Xilinx, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) Xilinx shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or Xilinx had been advised of the
// possibility of the same.
//
// CRITICAL APPLICATIONS
// Xilinx products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of Xilinx products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
//
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
//-----------------------------------------------------------------------------


#ifndef XIP_SD_FEC_v1_1_BITACC_CMODEL_H
#define XIP_SD_FEC_v1_1_BITACC_CMODEL_H

// Common typedefs, constants and functions for use across Xilinx bit-accurate C models
#undef XIP_XILINX_XIP_TARGET
#define XIP_XILINX_XIP_TARGET sd_fec_v1_1
#include "xip_common_bitacc_cmodel.h"

#ifdef __cplusplus
extern "C" {
#endif

//-----------------------------------------------------------------------------

// Parameter I/F constants
#define XIP_SD_FEC_v1_1_PARAM_FEC_LDPC  1
#define XIP_SD_FEC_v1_1_PARAM_FEC_TURBO 0

#define XIP_SD_FEC_v1_1_PARAM_TURBO_ALG_MAX      0
#define XIP_SD_FEC_v1_1_PARAM_TURBO_ALG_MAXSTAR  1

#define XIP_SD_FEC_v1_1_STANDARD_OTHER              0
#define XIP_SD_FEC_v1_1_STANDARD_5G_DECODE          1
#define XIP_SD_FEC_v1_1_STANDARD_5G_ENCODE          2
#define XIP_SD_FEC_v1_1_STANDARD_WIFI_802_11_DECODE 3
#define XIP_SD_FEC_v1_1_STANDARD_WIFI_802_11_ENCODE 4
#define XIP_SD_FEC_v1_1_STANDARD_DOCSIS_3_1_DECODE  5
#define XIP_SD_FEC_v1_1_STANDARD_DOCSIS_3_1_ENCODE  6

// Control I/F constants
#define XIP_SD_FEC_v1_1_CTRL_DECODE 0
#define XIP_SD_FEC_v1_1_CTRL_ENCODE 1

// Scale overide default
#define XIP_SD_FEC_v1_1_SCALE_OVERRIDE_DISABLED 16

// LDPC code status constants
#define XIP_SD_FEC_v1_1_LDPC_CODE_ERROR    0
#define XIP_SD_FEC_v1_1_LDPC_CODE_ENC_ONLY 1
#define XIP_SD_FEC_v1_1_LDPC_CODE_DEC_ONLY 2
#define XIP_SD_FEC_v1_1_LDPC_CODE_BOTH     3

//-----------------------------------------------------------------------------

/**
	* xip_sd_fec_v1_1_config Core configuration structure.
	*
	* Must be created and populated in order to instantiate the model.
	*/
typedef struct {
  
	const char*  name;                      /*@- Instance name to use in error/warning reporting */
	xip_uint     fec;                       /*@- FEC code: XIP_SD_FEC_v1_1_PARAM_FEC_TURBO or XIP_SD_FEC_v1_1_PARAM_FEC_LDPC  */
	xip_uint     standard;                  /*@- Standard: 0 = Other, 1 = 5G Decode, 2 = 5G Encode, 3 = WIFI 802.11 Decode, 4 = WIFI 802.11 Encode, 5 = DOCSIS v3.1 Decode, 6 = DOCSIS v3.1 Encode */
	xip_uint     scale_override;            /*@- Override normalization scale factor defined by non-5G standard default or LDPC code initialization file: factor =  scale_override * 0.0625, e.g. 12 = 0.75 */
	const char*  ldpc_code_initialization;  /*@- LDPC code initialization file (YAML format). Path to an LDPC code definition file containing the code definition(s) the model instance is to be initialized with. */
	xip_bit      bypass;                    /*@- Bypass error correction: 0 = Normal operation, 1 = Output same as input accounting for any soft to hard conversion */
	xip_uint     ip_quant_mode;             /*@- 0 = Quantize and saturate to Decoder LLR limits, 1 = Quantize and wrap at input width limits as per H/W */
} xip_sd_fec_v1_1_config;

/**
 * Object type (opaque to user).
 */
struct xip_sd_fec_v1_1_imp;
typedef struct xip_sd_fec_v1_1_imp xip_sd_fec_v1_1;

typedef xip_uint xip_sd_fec_v1_1_ldpc_sc_table;

struct xip_sd_fec_v1_1_ldpc_la_table;

struct xip_sd_fec_v1_1_ldpc_qc_table;

typedef struct {
  xip_uint                   n;               /*@- Number of codeword bits */
  xip_uint                   k;               /*@- Number of information bits */
  xip_uint                   psize;           /*@- Size of sub-matrix */
  xip_uint                   nlayers;         /*@- Number of layers in code */
  xip_uint                   nqc;             /*@- Number of entries in the QC table. */
  xip_uint                   nmqc;            /*@- Number of M-sized QC operations in parity check matrix for code */
  xip_uint                   nm;              /*@- Number of M-sized vectors in N (codeword bits) */
  xip_uint                   norm_type;       /*@- Normalization type: 0 = none; 1 = row (layer) scaling */
  xip_bit                    no_packing;      /*@- QC operation packing: 0 = Pack multiple QC operations; 1= Do not pack multiple QC operations*/
  xip_bit                    special_qc;      /*@- Indicates QC mode */
  xip_bit                    no_final_parity; /*@- Omit final parity check following final decoder iteration. */
  xip_uint                   max_schedule;    /*@- Scheduling control parameter, used by C model.*/
  xip_sd_fec_v1_1_ldpc_sc_table* sc_table;        /*@- Pointer to scale table array */
  xip_sd_fec_v1_1_ldpc_la_table* la_table;        /*@- Pointer to layer table array */
  xip_sd_fec_v1_1_ldpc_qc_table* qc_table;        /*@- Pointer to QC table array */
} xip_sd_fec_v1_1_ldpc_parameters;

typedef struct {
  xip_uint alg;        /*@- Turbo Decode alogrithm; MAX or MAXSTAR */
  xip_uint scale;      /*@- Scale */
} xip_sd_fec_v1_1_td_parameters;

const xip_sd_fec_v1_1_td_parameters XIP_SD_FEC_v1_1_TD_PARAM_MAX_DEFAULT     = { XIP_SD_FEC_v1_1_PARAM_TURBO_ALG_MAX     , 12};
const xip_sd_fec_v1_1_td_parameters XIP_SD_FEC_v1_1_TD_PARAM_MAXSTAR_DEFAULT = { XIP_SD_FEC_v1_1_PARAM_TURBO_ALG_MAXSTAR , 0 };  // Set no scaling

typedef struct {
  xip_uint code;                 /*@- Non-5G LDPC: Code number; Turbo: Codeword size */
  xip_uint op;                   /*@- Non-5G LDPC: 0=Decode 1=Encode; Turbo: N/A */
  xip_uint z_j;                  /*@- 5G control    : Lifting factor */
  xip_uint z_set;                /*@- 5G control    : Base graph rotation set */
  xip_uint bg;                   /*@- 5G control    : Base graph */
  xip_uint sc_idx;               /*@- 5G control    : Scale index */
  xip_uint mb;                   /*@- 5G control    : Specifies NLAYERS */
  xip_bit  hard_op;              /*@- 0=Hard O/P 1=Soft O/P */
  xip_bit  include_parity_op;    /*@- 0=Output systematic only 1=Output systematic and parity */
  xip_bit  crc_type;             /*@- Turbo CRC check: 0=Code block 1=Transport block */
  xip_bit  term_on_pass;         /*@- Terminate on parity pass (LDPC) or CRC pass (Turbo) */
  xip_bit  term_on_no_change;    /*@- Terminate if hard decision of whole codeword does not change between iterations */
  xip_uint max_iterations;       /*@-  */
  xip_uint id;                   /*@- External block identifier */
} xip_sd_fec_v1_1_ctrl_packet;


typedef struct {
  xip_uint code;              /*@- Non-5G LDPC: Code number; Turbo: Codeword size */
  xip_uint op;                /*@- Non-5G LDPC: 0=Decode 1=Encode; Turbo: N/A */
  xip_bit  crc_type;          /*@- Turbo CRC check: 0=Code block 1=Transport block */
  xip_uint z_j;               /*@- 5G status    : Lifting factor */
  xip_uint z_set;             /*@- 5G status    : Base graph rotation set */
  xip_uint bg;                /*@- 5G status    : Base graph */
  xip_uint mb;                /*@- 5G status    : Specifies NLAYERS */
  xip_bit  hard_op;           /*@- 0=Hard O/P 1=Soft O/P */
  xip_bit  pass;              /*@- Parity or CRC check passed */
  xip_bit  term_pass;         /*@- Terminated as parity or CRC check passed */
  xip_bit  term_no_change;    /*@- Terminated as no change in decoded bits from previous iteration */
  xip_uint dec_iter;          /*@- Number of iterations taken to decode output */
  xip_uint id;                /*@- External block identifier as supplied by CNTRL packet */
} xip_sd_fec_v1_1_stat_packet;

//-----------------------------------------------------------------------------

/**
 * Get version of library.
 *
 * @returns   String  Textual representation of library version
 */
XIP_XILINX_XIP_IMPEXP
const char* xip_sd_fec_v1_1_get_version(void);

/**
 * Create a new instance of the core based on some configuration values.
 *
 * @param     config      Pointer to a xip_sd_fec_v1_1_config structure
 * @param     handler     Callback function for errors and warnings (or null to output to stderr/stdout)
 * @param     handle      Optional argument to be passed back to callback function
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_sd_fec_v1_1* xip_sd_fec_v1_1_create(
  const xip_sd_fec_v1_1_config* config,
  xip_msg_handler msg_handler,
  void* msg_handle
);

/**
 * Reset an instance of the core.
 *
 * @param     model       Pointer to xip_sd_fec_v1_1 state structure
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_reset(xip_sd_fec_v1_1* model);

/**
 * Set/change configuration parameters
 *
 * @param     model       Pointer to xip_sd_fec_v1_1 state structure
 * @param     params      Pointer to xip_sd_fec_v1_1_config containing configuration parameters
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_set_config_params(
  xip_sd_fec_v1_1*                     model,
  const xip_sd_fec_v1_1_config*        params
);

/**
 * Generate LDPC specification from parity check matrix (H) 
 *
 * @param     H           Parity check matrix (Quasi-cyclic code)
 * @param     psize       Sub-matix size
 * @param     spec        Output LDPC code specification file (YAML format)
 * @param     handler     Callback function for errors and warnings (or null to output to stderr/stdout)
 * @param     handle      Optional argument to be passed back to callback function
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_gen_ldpc_spec(
  const xip_array_real* H,
  xip_uint              psize,
  const char*           spec,
  xip_msg_handler       msg_handler,
  void*                 msg_handle
);

/**
 * Generate parity check matrix (H) from LDPC specification
 *
 * @param     spec        LDPC code specification file (YAML format)
 * @param     H           Pointer to xip_array_real to recieve the Parity check matrix (Quasi-cyclic code)
 * @param     handler     Callback function for errors and warnings (or null to output to stderr/stdout)
 * @param     handle      Optional argument to be passed back to callback function
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_gen_parity_check_mat(
  const char*       spec,
  xip_array_real*   H,
  xip_msg_handler   msg_handler,
  void*             msg_handle
);

/**
 * Generate LDPC parameters from code specification
 *
 * @param     spec        LDPC code specification file (YAML format)
 * @param     params      Pointer to xip_sd_fec_v1_1_ldpc_parameters structure to recieve the LDPC code parameters
 * @param     handler     Callback function for errors and warnings (or null to output to stderr/stdout)
 * @param     handle      Optional argument to be passed back to callback function
 *
 * @returns   status      Status indicating LDPC code compatibility. XIP_SD_FEC_v1_1_LDPC_CODE_*
 */
XIP_XILINX_XIP_IMPEXP
xip_uint xip_sd_fec_v1_1_gen_ldpc_params(
  const char*                      spec,
  xip_sd_fec_v1_1_ldpc_parameters* params,
  xip_msg_handler                  msg_handler,
  void*                            msg_handle
);

/**
 * Destroy LDPC parameter arrays/tables
 *
 * @param     params      Pointer to xip_sd_fec_v1_1_ldpc_parameters structure to be destroyed
 * @param     handler     Callback function for errors and warnings (or null to output to stderr/stdout)
 * @param     handle      Optional argument to be passed back to callback function
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_destroy_ldpc_params(
  xip_sd_fec_v1_1_ldpc_parameters* params,
  xip_msg_handler                  msg_handler,
  void*                            msg_handle
);

/**
 * Add an LDPC code
 *
 * @param     model       Pointer to xip_sd_fec_v1_1 state structure
 * @param     code_num    Code number; 1-32
 * @param     params      Pointer to xip_sd_fec_v1_1_ldpc_parameters containing LDPC code parameters
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_add_ldpc_params(
  xip_sd_fec_v1_1*                       model,
  xip_uint                           code_num,
  const xip_sd_fec_v1_1_ldpc_parameters* params
);

/**
 * Set Turbo parameters
 *
 * @param     model       Pointer to xip_sd_fec_v1_1 state structure
 * @param     params      Pointer to xip_sd_fec_v1_1_td_parameters containing Turbo parameters
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_set_turbo_params(
  xip_sd_fec_v1_1*                     model,
  const xip_sd_fec_v1_1_td_parameters* params
);

/**
 * Get the number of initialized/added LDPC codes
 *
 * @param     model              Pointer to xip_sd_fec_v1_1 state structure
 *
 * @returns   Number of codes    Will return -1 if model undefined or standard == 5G
 */
XIP_XILINX_XIP_IMPEXP
int xip_sd_fec_v1_1_get_num_ldpc_codes(
  xip_sd_fec_v1_1* model
);

/**
 * Fetch LDPC code parameters used by specified control packet
 * o The function will use the code field or z_j, z_set, bg and mb fields to determine which code parameters to return.
 *   The parameter array fields, sc_table, la_table & qc_table will be set to NULL.
 *
 * @param     model       Pointer to xip_sd_fec_v1_1 state structure
 * @param     ctrl        Pointer to xip_sd_fec_v1_1_ctrl_packet
 * @param     params      Pointer to xip_sd_fec_v1_1_ldpc_parameters struct to be populated
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_get_ldpc_params(
  xip_sd_fec_v1_1*                   model,
  const xip_sd_fec_v1_1_ctrl_packet* ctrl,
  xip_sd_fec_v1_1_ldpc_parameters*   params
);

/**
 * Process a codeword
 *
 * @param     model       Pointer to xip_sd_fec_v1_1 state structure
 * @param     ctrl        Pointer to xip_sd_fec_v1_1_ctrl_packet
 * @param     data        Pointer to xip_array_real structure containing codeword symbol data
 * @param     hard        Pointer to xip_array_bit structure to receive hard decoded data
 * @param     soft        Pointer to xip_array_real structure to receive soft decoded data
 * @param     stat        Pointer to xip_sd_fec_v1_1_stat_packet structure to recieve status information
 *
 * @returns   Exit code   XIP_STATUS_*
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_process(
  xip_sd_fec_v1_1*                     model,
  const xip_sd_fec_v1_1_ctrl_packet*   ctrl,
  const xip_array_real*                data,
  xip_array_bit*                       hard,
  xip_array_real*                      soft,
  xip_sd_fec_v1_1_stat_packet*         stat
);


/**
 * Destroy an instance of the core and free any resources allocated.
 *
 * @param     model       Pointer to xip_sd_fec_v1_1 state structure
 * @returns   Exit code   XIP_STATUS_*
 *
 */
XIP_XILINX_XIP_IMPEXP
xip_status xip_sd_fec_v1_1_destroy(xip_sd_fec_v1_1* model);

#ifdef __cplusplus
} /* End of "C" linkage block */
#endif

#endif

